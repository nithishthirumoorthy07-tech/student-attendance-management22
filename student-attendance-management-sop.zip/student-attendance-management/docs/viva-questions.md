# Viva Questions — Student Attendance Management and Analytics System

**1. What is CRUD?**
Create, Read, Update, Delete — the four basic operations performed on persistent data.

**2. What is REST?**
An architectural style for web APIs where resources are identified by URLs and manipulated using standard HTTP methods (GET, POST, PUT, DELETE).

**3. What is Spring Boot?**
A framework built on top of Spring that simplifies configuration and lets you build production-ready Java applications quickly, with an embedded server.

**4. Why use Spring Boot here?**
It provides auto-configuration, an embedded Tomcat server, and easy integration with Spring Data JPA, reducing boilerplate for a REST backend.

**5. What is JPA?**
Java Persistence API — a specification for mapping Java objects to relational database tables.

**6. What is Hibernate?**
The most common implementation of JPA; it generates SQL from annotated Java entities.

**7. What is MySQL?**
An open-source relational database management system used here to store students and attendance records.

**8. What is a primary key?**
A column (or set of columns) that uniquely identifies each row in a table — here, `id` in both `students` and `attendance`.

**9. What is a foreign key?**
A column that references the primary key of another table, enforcing referential integrity — `attendance.student_id` references `students.id`.

**10. What is `@Entity`?**
A JPA annotation marking a Java class as a table-mapped persistent object.

**11. What is `@RestController`?**
A Spring annotation combining `@Controller` and `@ResponseBody`, so return values are automatically serialized to JSON.

**12. What is `@Service`?**
An annotation marking a class as holding business logic, making it a Spring-managed bean.

**13. What is `@Repository`?**
An annotation (implicit for Spring Data JPA interfaces) marking a class responsible for data access.

**14. What is dependency injection?**
A design pattern where an object's dependencies are provided by a framework (Spring) rather than created manually — used here via constructor injection in services and controllers.

**15. What is GET used for?**
Retrieving data without changing server state (e.g. listing students).

**16. What is POST used for?**
Creating a new resource (e.g. adding a student).

**17. What is PUT used for?**
Updating an existing resource fully (e.g. editing a student's details).

**18. What is DELETE used for?**
Removing a resource (e.g. deleting an attendance record).

**19. Why use validation?**
To reject bad data early (empty names, invalid emails, out-of-range years) before it reaches the database, giving clear error messages.

**20. Why use exception handling?**
To convert internal errors into clean, predictable JSON responses instead of leaking stack traces, and to map different failure types to correct HTTP status codes.

**21. How does the frontend communicate with the backend?**
Via `fetch()` calls from JavaScript to REST endpoints under `/api/...`, exchanging JSON.

**22. What is JSON?**
JavaScript Object Notation — a lightweight, text-based data format used for API requests and responses.

**23. What is ORM?**
Object-Relational Mapping — translating between Java objects and relational database rows automatically (done here by Hibernate).

**24. Explain the database relationship in this project.**
One student has many attendance records (`Student` 1 —— MANY `Attendance`), modelled with `@OneToMany`/`@ManyToOne` and a foreign key.

**25. Explain the CRUD flow for a student.**
Frontend form → REST controller → service (validates, checks duplicates) → repository → Hibernate → MySQL → response JSON → frontend updates the table.

**26. Explain the attendance flow.**
Same as above, plus an extra check: the service verifies the student exists and that no attendance record already exists for that student on that date before saving.

**27. Explain the project's architecture.**
A layered architecture: Frontend → REST API → Controller → Service → Repository → JPA/Hibernate → MySQL, keeping each concern separate.

**28. What happens when a student is deleted?**
Their attendance records are deleted too, via `cascade = CascadeType.ALL, orphanRemoval = true` on the JPA side and `ON DELETE CASCADE` on the database foreign key.

**29. How is duplicate attendance prevented?**
Two layers: the service checks `existsByStudentIdAndDate()` before saving, and the database enforces a `UNIQUE(student_id, date)` constraint as a safety net against race conditions.

**30. Why use MySQL instead of a NoSQL database here?**
The data is naturally relational (students have many attendance records with strict uniqueness rules), which maps cleanly to tables, foreign keys, and constraints — a strength of relational databases.
