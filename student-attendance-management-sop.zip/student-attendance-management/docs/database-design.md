# Database Design — Student Attendance Management and Analytics System

Database name: **student_attendance_db** (MySQL)

## Entity relationship

```
STUDENTS
   │
   │ 1
   │
   │ MANY
   ▼
ATTENDANCE
```

One student can have **many** attendance records (one per date); each
attendance record belongs to **exactly one** student. This is implemented
with `Attendance.student` mapped `@ManyToOne`, and `Student.attendanceRecords`
mapped `@OneToMany(mappedBy = "student")`.

## Table: students

| Column | Type | Constraints |
|---|---|---|
| id | BIGINT | PRIMARY KEY, AUTO_INCREMENT |
| name | VARCHAR(100) | NOT NULL |
| roll_no | VARCHAR(30) | NOT NULL, UNIQUE |
| department | VARCHAR(100) | NOT NULL |
| email | VARCHAR(150) | NOT NULL |
| year | INT | NOT NULL |
| created_at | DATETIME | NOT NULL, defaults to current timestamp |

## Table: attendance

| Column | Type | Constraints |
|---|---|---|
| id | BIGINT | PRIMARY KEY, AUTO_INCREMENT |
| student_id | BIGINT | NOT NULL, FOREIGN KEY → students(id), ON DELETE CASCADE |
| date | DATE | NOT NULL |
| status | VARCHAR(10) | NOT NULL, CHECK (status IN ('PRESENT','ABSENT')) |
| created_at | DATETIME | NOT NULL, defaults to current timestamp |

**Composite constraint:** `UNIQUE (student_id, date)` — guarantees a student
can only have one attendance record per calendar day. This is enforced at
the database level (not just in application code), so it holds even under
concurrent requests.

## Why `ON DELETE CASCADE`?

Deleting a student should not leave orphaned attendance rows pointing at a
non-existent student. Cascading the delete keeps the database consistent
and matches the JPA-side `cascade = CascadeType.ALL, orphanRemoval = true`
configured on `Student.attendanceRecords`.

## Indexes

- `students.roll_no` — unique index (used for search and duplicate checks).
- `attendance(student_id, date)` — unique composite index (duplicate-prevention and fast lookups by student/date).

## Sample data

`database/schema.sql` includes a small set of optional sample rows purely to
make manual testing easier. They can be deleted before final submission
without affecting the schema.
