# Architecture — Student Attendance Management and Analytics System

## Overview

The system follows a classic **layered architecture**. The browser talks only
to the REST API; the REST API talks only to MySQL through Spring Data JPA.
No layer is skipped.

```
User
  │
  ▼
HTML + CSS + JavaScript (src/main/resources/static)
  │  fetch() calls, JSON
  ▼
REST API  (/api/students, /api/attendance, /api/dashboard)
  │
  ▼
Spring Boot Controller  (StudentController, AttendanceController, DashboardController)
  │  delegates business rules, never touches the database directly
  ▼
Service Layer  (StudentService, AttendanceService, DashboardService)
  │  validation, duplicate checks, DTO mapping
  ▼
Spring Data JPA Repository  (StudentRepository, AttendanceRepository)
  │
  ▼
Hibernate / JPA
  │
  ▼
MySQL Database  (student_attendance_db)
```

## Layer responsibilities

| Layer | Responsibility |
|---|---|
| Frontend (HTML/CSS/JS) | Renders pages, collects form input, calls the REST API with `fetch()`, shows success/error messages |
| Controller | Accepts HTTP requests, validates request shape with `@Valid`, returns HTTP status codes |
| Service | Business rules — uniqueness checks, duplicate-attendance checks, DTO ↔ entity conversion |
| Repository | Spring Data JPA interfaces — no manual SQL, no string concatenation |
| Entity / Hibernate | Object-relational mapping to MySQL tables |
| MySQL | Persistent storage, enforces `UNIQUE` and `FOREIGN KEY` constraints as a safety net |

## Create flow (example: Add Student)

1. User fills the form on `students.html` and clicks **Add Student**.
2. `students.js` runs `fetch('/api/students', { method: 'POST', body: JSON.stringify(payload) })`.
3. `StudentController.createStudent()` receives the JSON, Spring validates it against `StudentRequestDTO`.
4. `StudentService.createStudent()` checks `existsByRollNo()`; if it already exists it throws `DuplicateResourceException` (→ HTTP 409).
5. Otherwise a `Student` entity is built and saved through `StudentRepository.save()`.
6. Hibernate issues an `INSERT` into the `students` table.
7. The saved entity is converted back into a `StudentResponseDTO` and returned as JSON with HTTP 201.
8. The frontend shows "Student added successfully." and refreshes the table.

## Read / Update / Delete flow

- **Read**: `GET /api/students` or `/api/students/{id}` → `StudentService` → `StudentRepository.findAll()`/`findById()` → JSON list or object.
- **Update**: `PUT /api/students/{id}` → service loads the existing entity, re-checks roll-number uniqueness (excluding itself), applies changes, saves.
- **Delete**: `DELETE /api/students/{id}` → service loads the entity (404 if missing) → `studentRepository.delete()`. Because `Student.attendanceRecords` is mapped with `cascade = ALL, orphanRemoval = true`, and the database foreign key uses `ON DELETE CASCADE`, the student's attendance history is removed automatically and consistently at both the JPA and database level.

## Attendance flow

1. Frontend loads the list of students into a dropdown (`GET /api/students`).
2. User selects a student, a date, and a status, then submits.
3. `AttendanceService.createAttendance()` first confirms the student exists, then calls `existsByStudentIdAndDate()`.
4. If a record already exists for that student/date, `DuplicateResourceException` is thrown (HTTP 409) — this is backed by the database's own `UNIQUE(student_id, date)` constraint as a second line of defence.
5. Otherwise the attendance row is inserted and returned to the frontend, which appends it to the table.

## Dashboard flow

`GET /api/dashboard/stats` triggers `DashboardService.getStats()`, which runs four repository queries against MySQL (`count()`, `countByDateAndStatus()`, `countByStatus()`) and computes the attendance percentage as:

```
Attendance Percentage = (Total PRESENT records / Total attendance records) × 100
```

If there are zero attendance records, the percentage is returned as `0` instead of dividing by zero.
