# SOP Compliance Summary

| SOP Requirement | Project Implementation | Status |
|---|---|---|
| Requirement Analysis | Features derived from the provided SOP (Dashboard, Student Management, Attendance Management) | Completed |
| Project Planning | Layered architecture + file structure planned before coding (see docs/architecture.md) | Completed |
| Database Design | MySQL schema with `students` and `attendance` tables, FK + UNIQUE constraints (see docs/database-design.md) | Completed |
| Frontend | HTML5 + CSS3 + Vanilla JavaScript, served from `src/main/resources/static` | Completed |
| Backend | Spring Boot (Web, Data JPA, Validation) | Completed |
| Database | MySQL via Spring Data JPA + Hibernate | Completed |
| Create | `POST /api/students`, `POST /api/attendance` | Completed |
| Read | `GET /api/students`, `GET /api/students/{id}`, `GET /api/attendance`, `GET /api/attendance/{id}` | Completed |
| Update | `PUT /api/students/{id}`, `PUT /api/attendance/{id}` | Completed |
| Delete | `DELETE /api/students/{id}`, `DELETE /api/attendance/{id}` | Completed |
| Validation | Client-side (JS) + server-side (`@NotBlank`, `@Email`, `@Min`, `@Max`, `@NotNull`) | Completed |
| Exception Handling | `GlobalExceptionHandler` with `@RestControllerAdvice`, clean JSON errors, no stack traces exposed | Completed |
| Search & Filtering | Student search by name/roll number; department/year filters; attendance filters by date/student/status | Completed |
| Testing | 30 manual test cases (docs/testing.md) + JUnit/Mockito unit tests for `StudentService` | Completed |
| Security basics | No hard-coded credentials, DB password via environment variable, JPA (no raw SQL concatenation) | Completed |
| Version Control | `.gitignore` provided, README documents `git init`/`add`/`commit`/`push` steps | Completed |
| Documentation | README, architecture, database design, API docs, testing doc, viva questions, this SOP table | Completed |
| Demonstration readiness | App runs at `http://localhost:8080`; Postman collection described in api-documentation.md | Completed |
| Frontend-Backend Integration | `fetch()`-based REST calls from JS, JSON in/out, live dashboard stats | Completed |

Only items that are actually implemented in the codebase are marked
"Completed" — nothing in this table is aspirational.
