# Testing Document — Student Attendance Management and Analytics System

Run these manually against the running application (`http://localhost:8080`)
using the frontend pages and/or Postman. Fill in **Actual Result** and
**Status** columns as you execute each test.

| Test ID | Module | Test Case | Input | Expected Result | Actual Result | Status |
|---|---|---|---|---|---|---|
| TC01 | Student | Add valid student | Complete valid form | Student created, success message shown | | |
| TC02 | Student | Empty student name | Name left blank | "Please fill all required fields." shown, no API call / 400 | | |
| TC03 | Student | Empty roll number | Roll number left blank | Validation error shown | | |
| TC04 | Student | Empty department | Department left blank | Validation error shown | | |
| TC05 | Student | Invalid email | `abc.com` (no @) | "Invalid email address." shown | | |
| TC06 | Student | Invalid year | Year = 9 | 400 response, "Year must be between 1 and 5" | | |
| TC07 | Student | Duplicate roll number | Roll number already used by another student | 409 response, "Roll number already exists." | | |
| TC08 | Student | View students | Open students.html | Table lists all students from MySQL | | |
| TC09 | Student | View one student | GET /api/students/{id} | Correct single student JSON | | |
| TC10 | Student | Update student | Change name/department, submit | Student updated, table reflects change | | |
| TC11 | Student | Invalid student ID | GET /api/students/9999 | 404, "Student not found" | | |
| TC12 | Student | Delete student | Click Delete, confirm | Student removed, attendance records also removed | | |
| TC13 | Student | Cancel delete | Click Delete, cancel confirm dialog | No change made | | |
| TC14 | Student | Search student | Type partial name or roll number | Matching students shown | | |
| TC15 | Student | Department filter | Filter by department | Only that department's students shown | | |
| TC16 | Student | Year filter | Filter by year | Only that year's students shown | | |
| TC17 | Attendance | Add attendance | Select student, date, status | Attendance saved, success message | | |
| TC18 | Attendance | Present attendance | Status = PRESENT | Record saved with PRESENT badge | | |
| TC19 | Attendance | Absent attendance | Status = ABSENT | Record saved with ABSENT badge | | |
| TC20 | Attendance | Duplicate attendance | Same student + same date submitted twice | 409, "Attendance already exists for this student on this date." | | |
| TC21 | Attendance | Invalid student for attendance | studentId that does not exist (via Postman) | 404, "Student not found" | | |
| TC22 | Attendance | Attendance date filter | Filter by date | Only that date's records shown | | |
| TC23 | Attendance | Attendance status filter | Filter by PRESENT/ABSENT | Only matching records shown | | |
| TC24 | Attendance | Update attendance | Change status from PRESENT to ABSENT | Record updated | | |
| TC25 | Attendance | Delete attendance | Click Delete, confirm | Record removed from table | | |
| TC26 | Dashboard | Dashboard statistics | Open index.html | Total/present/absent/percentage match MySQL data | | |
| TC27 | Resilience | Backend unavailable | Stop the Spring Boot app, use frontend | "Unable to connect to server." shown, no crash | | |
| TC28 | Resilience | Database unavailable | Stop MySQL, start Spring Boot | Application logs a clear connection error on startup | | |
| TC29 | UI | Mobile responsiveness | Open pages at ~375px width | Layout stacks into single-column cards, tables become stacked cards | | |
| TC30 | API | API testing through Postman | Run all CRUD requests from api-documentation.md | Correct status codes and JSON bodies returned | | |

## How to execute

1. Start MySQL and run `database/schema.sql`.
2. Start the app with `mvn spring-boot:run`.
3. Walk through TC01–TC29 using the browser at `http://localhost:8080`.
4. Import the endpoints from `docs/api-documentation.md` into Postman for TC30 and to double check status codes for TC06, TC07, TC11, TC20, TC21.
