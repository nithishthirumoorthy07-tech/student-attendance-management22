# API Documentation — Student Attendance Management and Analytics System

Base URL (local): `http://localhost:8080`

All request/response bodies are JSON. All error responses follow:

```json
{ "status": 404, "message": "Student not found" }
```

---

## Student APIs

### Create Student
`POST /api/students`

Request:
```json
{
  "name": "Arun Kumar",
  "rollNo": "ECE001",
  "department": "ECE",
  "email": "arun.kumar@example.edu",
  "year": 2
}
```

Response `201 Created`:
```json
{
  "id": 1,
  "name": "Arun Kumar",
  "rollNo": "ECE001",
  "department": "ECE",
  "email": "arun.kumar@example.edu",
  "year": 2,
  "createdAt": "2026-09-12T10:15:30"
}
```

Errors: `400` (validation failure), `409` (roll number already exists)

### Get All Students
`GET /api/students`

Optional query parameters: `search`, `department`, `year`
(e.g. `/api/students?department=ECE&year=2`)

Response `200 OK`: array of student objects.

### Get Single Student
`GET /api/students/{id}`

Response `200 OK`: a single student object. `404` if not found.

### Update Student
`PUT /api/students/{id}`

Request body: same shape as Create. Response `200 OK` with the updated
student. Errors: `400`, `404`, `409`.

### Delete Student
`DELETE /api/students/{id}`

Response `204 No Content`. `404` if the student does not exist.

---

## Attendance APIs

### Create Attendance
`POST /api/attendance`

Request:
```json
{
  "studentId": 1,
  "date": "2026-09-12",
  "status": "PRESENT"
}
```

Response `201 Created`:
```json
{
  "id": 10,
  "studentId": 1,
  "studentName": "Arun Kumar",
  "rollNo": "ECE001",
  "date": "2026-09-12",
  "status": "PRESENT",
  "createdAt": "2026-09-12T10:20:00"
}
```

Errors: `400` (validation), `404` (student not found), `409` (attendance already exists for this student on this date)

### Get All Attendance
`GET /api/attendance`

Optional query parameters: `date`, `studentId`, `status`.

### Get Single Attendance
`GET /api/attendance/{id}` — `200 OK` or `404`.

### Update Attendance
`PUT /api/attendance/{id}` — same body shape as Create. `200 OK`, `400`, `404`, `409`.

### Delete Attendance
`DELETE /api/attendance/{id}` — `204 No Content`, or `404`.

### Filter by Date (path variant)
`GET /api/attendance/date/{date}` — e.g. `/api/attendance/date/2026-09-12`

### Filter by Student (path variant)
`GET /api/attendance/student/{studentId}`

### Filter by Status (path variant)
`GET /api/attendance/status/{status}` — `status` is `PRESENT` or `ABSENT`

---

## Dashboard API

### Get Dashboard Statistics
`GET /api/dashboard/stats`

Response `200 OK`:
```json
{
  "totalStudents": 25,
  "presentToday": 20,
  "absentToday": 5,
  "attendancePercentage": 80.0
}
```

All four values are computed live from MySQL on every call.

---

## HTTP status codes used

| Code | Meaning |
|---|---|
| 200 | Success (GET, PUT) |
| 201 | Resource created (POST) |
| 204 | Resource deleted, no body |
| 400 | Validation error / bad input |
| 404 | Resource not found |
| 409 | Conflict — duplicate roll number or duplicate attendance |
| 500 | Unexpected server error |
