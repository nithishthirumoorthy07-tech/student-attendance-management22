# Student Attendance Management and Analytics System

A complete, SOP-compliant CRUD web application for managing student records
and daily attendance, built with **HTML/CSS/JavaScript**, **Spring Boot**,
**Spring Data JPA/Hibernate**, and **MySQL**.

---

## 1. Project Overview

This application lets a college track students and their daily attendance
through a browser-based dashboard, backed by a real REST API and a real
MySQL database — no mock data, no browser storage pretending to be a
database.

## 2. Problem Statement

Manually tracking attendance on paper or in spreadsheets is error-prone and
hard to search, filter, or summarize. This system centralizes student
records and daily attendance in a relational database with a simple web
interface for data entry and reporting.

## 3. Objectives

- Provide full CRUD for students and attendance records.
- Enforce data integrity (unique roll numbers, one attendance entry per
  student per day).
- Expose a clean REST API that a frontend (or Postman) can consume.
- Present live dashboard statistics computed from the database.
- Be simple enough to explain and defend in a college viva.

## 4. Features

- **Dashboard**: total students, present today, absent today, attendance
  percentage — all computed live from MySQL.
- **Student Management**: add, view, edit, delete, search, filter.
- **Attendance Management**: mark present/absent, view, edit, delete,
  filter by date/student/status.
- Client-side and server-side validation.
- Centralized exception handling with clean JSON errors.
- Responsive design (desktop, tablet, mobile).

## 5. Technology Stack

**Frontend:** HTML5, CSS3, Vanilla JavaScript
**Backend:** Java, Spring Boot, Spring Web, Spring Data JPA, Hibernate, Bean Validation
**Database:** MySQL
**Build Tool:** Maven
**API:** REST + JSON
**API Testing:** Postman
**Version Control:** Git, GitHub

## 6. Architecture

```
User → HTML/CSS/JS → REST API → Spring Boot Controller → Service Layer
     → Spring Data JPA Repository → Hibernate/JPA → MySQL Database
```

Full details: [`docs/architecture.md`](docs/architecture.md)

## 7. Database Design

Two tables — `students` and `attendance` — with a one-to-many relationship
enforced by a foreign key, plus a `UNIQUE(student_id, date)` constraint that
prevents duplicate attendance. Full details:
[`docs/database-design.md`](docs/database-design.md)

## 8. CRUD Operations

Both Students and Attendance support Create, Read, Update, and Delete
through the REST API and the frontend UI.

## 9. REST APIs

Every endpoint, with example requests/responses, is documented in
[`docs/api-documentation.md`](docs/api-documentation.md).

## 10. Validation

- **Client-side**: required-field checks and email format checks in
  `students.js` / `attendance.js` before any request is sent.
- **Server-side**: Bean Validation annotations (`@NotBlank`, `@Email`,
  `@Min`, `@Max`, `@NotNull`) on `StudentRequestDTO` and
  `AttendanceRequestDTO`, enforced by `@Valid` in the controllers.

## 11. Exception Handling

`GlobalExceptionHandler` (`@RestControllerAdvice`) converts every failure —
not found, duplicate, validation, bad ID, unexpected error — into a clean
JSON body: `{"status": 404, "message": "Student not found"}`. Stack traces
are never sent to the frontend.

## 12. Search and Filtering

- Students: search by name or roll number; filter by department and/or year.
- Attendance: filter by date, student, and/or status.

## 13. Project Structure

```
student-attendance-management/
├── src/
│   ├── main/
│   │   ├── java/com/example/studentattendance/
│   │   │   ├── StudentAttendanceApplication.java
│   │   │   ├── controller/   (StudentController, AttendanceController, DashboardController)
│   │   │   ├── service/      (StudentService, AttendanceService, DashboardService)
│   │   │   ├── repository/   (StudentRepository, AttendanceRepository)
│   │   │   ├── entity/       (Student, Attendance, AttendanceStatus)
│   │   │   ├── dto/          (request/response DTOs, ApiErrorResponse)
│   │   │   └── exception/    (ResourceNotFoundException, DuplicateResourceException, GlobalExceptionHandler)
│   │   └── resources/
│   │       ├── application.properties
│   │       └── static/
│   │           ├── index.html, students.html, attendance.html
│   │           ├── css/style.css
│   │           └── js/dashboard.js, students.js, attendance.js
│   └── test/java/com/example/studentattendance/StudentServiceTest.java
├── database/schema.sql
├── docs/
│   ├── architecture.md
│   ├── database-design.md
│   ├── api-documentation.md
│   ├── testing.md
│   ├── viva-questions.md
│   └── sop-compliance.md
├── screenshots/README.md
├── pom.xml
├── README.md
└── .gitignore
```

## 14. Prerequisites

- Java 17 or later
- Maven 3.8+ (or use an IDE with bundled Maven)
- MySQL 8.0+
- Postman (optional, for API testing)

## 15. Java Installation

Install a JDK (17 or later). Verify with:
```
java -version
```

## 16. Maven Requirements

Install Maven, or use an IDE (IntelliJ IDEA, Eclipse, VS Code) with a
bundled Maven/Gradle-aware Spring Boot runner. Verify with:
```
mvn -version
```

## 17. MySQL Installation

Install MySQL Server 8.0+ and make sure it's running on `localhost:3306`.

## 18. Database Setup

Run the provided schema script once:
```
mysql -u root -p < database/schema.sql
```
This creates the `student_attendance_db` database along with the
`students` and `attendance` tables, plus a small amount of optional sample
data.

## 19. Configuration

Set your MySQL credentials as environment variables before running the app
(do **not** hard-code them):

```
export DB_USERNAME=root
export DB_PASSWORD=your_mysql_password
```

On Windows (PowerShell):
```
$env:DB_USERNAME="root"
$env:DB_PASSWORD="your_mysql_password"
```

These map to `spring.datasource.username` / `spring.datasource.password` in
`src/main/resources/application.properties`.

## 20. How to Run

```
mvn spring-boot:run
```

Then open:
```
http://localhost:8080
```

The dashboard (`index.html`) loads first; use the navigation bar to reach
Students and Attendance.

## 21. How to Test

Follow the 30 manual test cases in [`docs/testing.md`](docs/testing.md),
or run the included unit tests:
```
mvn test
```

## 22. Postman Testing

Import the endpoints below manually into Postman (or build a collection
from [`docs/api-documentation.md`](docs/api-documentation.md)):

```
POST   http://localhost:8080/api/students
GET    http://localhost:8080/api/students
GET    http://localhost:8080/api/students/1
PUT    http://localhost:8080/api/students/1
DELETE http://localhost:8080/api/students/1

POST   http://localhost:8080/api/attendance
GET    http://localhost:8080/api/attendance
PUT    http://localhost:8080/api/attendance/1
DELETE http://localhost:8080/api/attendance/1

GET    http://localhost:8080/api/dashboard/stats
```

Sample POST body for a student:
```json
{
  "name": "Arun Kumar",
  "rollNo": "ECE001",
  "department": "ECE",
  "email": "arun.kumar@example.edu",
  "year": 2
}
```

Sample POST body for attendance:
```json
{
  "studentId": 1,
  "date": "2026-09-12",
  "status": "PRESENT"
}
```

## 23. GitHub Upload

```
git init
git add .
git commit -m "Initial SOP CRUD project"
git branch -M main
git remote add origin YOUR_GITHUB_REPOSITORY_URL
git push -u origin main
```
Replace `YOUR_GITHUB_REPOSITORY_URL` with your actual repository URL.

## 24. Screenshots

See [`screenshots/README.md`](screenshots/README.md) for the list of
screenshots to capture from your own running instance before submission.

## 25. Challenges and Solutions

- **Preventing duplicate attendance reliably**: solved with both an
  application-level check (`existsByStudentIdAndDate`) and a database-level
  `UNIQUE(student_id, date)` constraint, so the rule holds even under
  concurrent requests.
- **Keeping controllers thin**: all business rules (uniqueness, duplicate
  checks, DTO mapping) live in the service layer, not the controllers.
- **Safe error messages**: a single `GlobalExceptionHandler` ensures no
  stack trace ever reaches the frontend.

## 26. Future Enhancements

- Authentication/authorization for staff vs. admin roles.
- Monthly/semester attendance reports and CSV export.
- Pagination for large student lists.
- Email/SMS notifications for low attendance.

## 27. Limitations

- No login system — anyone with access to the app can modify records.
- No file upload for bulk student import.
- Single-department UI (department is a free-text field, not a fixed list).

## 28. Viva Explanation

See [`docs/viva-questions.md`](docs/viva-questions.md) for 30 questions and
answers covering CRUD, REST, Spring Boot, JPA/Hibernate, database design,
and this project's specific flows — written to be easy to explain in a
short viva.

---

## SOP Compliance

See [`docs/sop-compliance.md`](docs/sop-compliance.md) for the full
requirement-by-requirement compliance table.
