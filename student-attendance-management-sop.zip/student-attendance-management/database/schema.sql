-- ==========================================================
-- Student Attendance Management and Analytics System
-- MySQL schema
-- Run this once before starting the application, e.g.:
--   mysql -u root -p < database/schema.sql
-- ==========================================================

CREATE DATABASE IF NOT EXISTS student_attendance_db;

USE student_attendance_db;

-- ----------------------------------------------------------
-- Table: students
-- ----------------------------------------------------------
CREATE TABLE IF NOT EXISTS students (
    id          BIGINT AUTO_INCREMENT PRIMARY KEY,
    name        VARCHAR(100) NOT NULL,
    roll_no     VARCHAR(30)  NOT NULL,
    department  VARCHAR(100) NOT NULL,
    email       VARCHAR(150) NOT NULL,
    year        INT          NOT NULL,
    created_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uk_students_roll_no UNIQUE (roll_no)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------------------------------------
-- Table: attendance
-- ----------------------------------------------------------
CREATE TABLE IF NOT EXISTS attendance (
    id          BIGINT AUTO_INCREMENT PRIMARY KEY,
    student_id  BIGINT       NOT NULL,
    date        DATE         NOT NULL,
    status      VARCHAR(10)  NOT NULL,
    created_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_attendance_student
        FOREIGN KEY (student_id) REFERENCES students(id)
        ON DELETE CASCADE,
    CONSTRAINT uk_attendance_student_date UNIQUE (student_id, date),
    CONSTRAINT chk_attendance_status CHECK (status IN ('PRESENT', 'ABSENT'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------------------------------------
-- Optional sample data (safe to remove before submission)
-- ----------------------------------------------------------
INSERT INTO students (name, roll_no, department, email, year) VALUES
    ('Arun Kumar', 'ECE001', 'ECE', 'arun.kumar@example.edu', 2),
    ('Divya Sri', 'ECE002', 'ECE', 'divya.sri@example.edu', 2),
    ('Karthik R', 'CSE001', 'CSE', 'karthik.r@example.edu', 3)
ON DUPLICATE KEY UPDATE name = VALUES(name);

INSERT INTO attendance (student_id, date, status) VALUES
    (1, CURDATE(), 'PRESENT'),
    (2, CURDATE(), 'ABSENT'),
    (3, CURDATE(), 'PRESENT')
ON DUPLICATE KEY UPDATE status = VALUES(status);
