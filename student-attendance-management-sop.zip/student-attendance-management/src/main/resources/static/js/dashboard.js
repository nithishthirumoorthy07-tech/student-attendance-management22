// ==========================================================
// Dashboard logic — fetches live stats from /api/dashboard/stats
// ==========================================================

const API_BASE = '/api';

const el = {
    message: document.getElementById('message'),
    totalStudents: document.getElementById('statTotalStudents'),
    presentToday: document.getElementById('statPresentToday'),
    absentToday: document.getElementById('statAbsentToday'),
    percentage: document.getElementById('statPercentage'),
};

function showMessage(text, type) {
    el.message.textContent = text;
    el.message.className = 'message ' + type;
    setTimeout(() => { el.message.className = 'message'; }, 4000);
}

async function loadStats() {
    try {
        const response = await fetch(`${API_BASE}/dashboard/stats`);
        if (!response.ok) {
            throw new Error('Failed to load dashboard statistics');
        }
        const stats = await response.json();
        el.totalStudents.textContent = stats.totalStudents;
        el.presentToday.textContent = stats.presentToday;
        el.absentToday.textContent = stats.absentToday;
        el.percentage.textContent = stats.attendancePercentage + '%';
    } catch (err) {
        showMessage('Unable to connect to server.', 'error');
    }
}

document.addEventListener('DOMContentLoaded', loadStats);
