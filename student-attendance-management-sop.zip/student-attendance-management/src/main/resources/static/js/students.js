// ==========================================================
// Student management page logic
// Handles Create, Read, Update, Delete, Search and Filter
// via the REST API at /api/students
// ==========================================================

const API_BASE = '/api';

const el = {
    message: document.getElementById('message'),
    form: document.getElementById('studentForm'),
    formTitle: document.getElementById('formTitle'),
    studentId: document.getElementById('studentId'),
    name: document.getElementById('name'),
    rollNo: document.getElementById('rollNo'),
    department: document.getElementById('department'),
    email: document.getElementById('email'),
    year: document.getElementById('year'),
    submitBtn: document.getElementById('submitBtn'),
    cancelBtn: document.getElementById('cancelBtn'),
    tableBody: document.getElementById('studentsTableBody'),
    emptyState: document.getElementById('emptyState'),
    searchInput: document.getElementById('searchInput'),
    departmentFilter: document.getElementById('departmentFilter'),
    yearFilter: document.getElementById('yearFilter'),
    applyFilterBtn: document.getElementById('applyFilterBtn'),
    clearFilterBtn: document.getElementById('clearFilterBtn'),
};

function showMessage(text, type) {
    el.message.textContent = text;
    el.message.className = 'message ' + type;
    setTimeout(() => { el.message.className = 'message'; }, 4000);
}

function resetForm() {
    el.form.reset();
    el.studentId.value = '';
    el.formTitle.textContent = 'Add Student';
    el.submitBtn.textContent = 'Add Student';
    el.cancelBtn.style.display = 'none';
}

function renderStudents(students) {
    el.tableBody.innerHTML = '';
    if (!students || students.length === 0) {
        el.emptyState.style.display = 'block';
        return;
    }
    el.emptyState.style.display = 'none';

    students.forEach((s) => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td data-label="ID">${s.id}</td>
            <td data-label="Name">${escapeHtml(s.name)}</td>
            <td data-label="Roll Number">${escapeHtml(s.rollNo)}</td>
            <td data-label="Department">${escapeHtml(s.department)}</td>
            <td data-label="Email">${escapeHtml(s.email)}</td>
            <td data-label="Year">${s.year}</td>
            <td data-label="Actions">
                <button class="btn-primary btn-small" data-action="edit" data-id="${s.id}">Edit</button>
                <button class="btn-danger btn-small" data-action="delete" data-id="${s.id}">Delete</button>
            </td>
        `;
        el.tableBody.appendChild(row);
    });
}

function escapeHtml(value) {
    const div = document.createElement('div');
    div.textContent = value ?? '';
    return div.innerHTML;
}

async function loadStudents() {
    try {
        const response = await fetch(`${API_BASE}/students`);
        if (!response.ok) throw new Error('Failed to load students');
        const students = await response.json();
        renderStudents(students);
    } catch (err) {
        showMessage('Unable to connect to server.', 'error');
    }
}

async function applyFilters() {
    const search = el.searchInput.value.trim();
    const department = el.departmentFilter.value.trim();
    const year = el.yearFilter.value;

    const params = new URLSearchParams();
    if (search) params.append('search', search);
    if (department) params.append('department', department);
    if (year) params.append('year', year);

    try {
        const response = await fetch(`${API_BASE}/students?${params.toString()}`);
        if (!response.ok) throw new Error('Failed to load students');
        const students = await response.json();
        renderStudents(students);
    } catch (err) {
        showMessage('Unable to connect to server.', 'error');
    }
}

function clearFilters() {
    el.searchInput.value = '';
    el.departmentFilter.value = '';
    el.yearFilter.value = '';
    loadStudents();
}

async function handleSubmit(event) {
    event.preventDefault();

    if (!el.name.value.trim() || !el.rollNo.value.trim() || !el.department.value.trim()
        || !el.email.value.trim() || !el.year.value) {
        showMessage('Please fill all required fields.', 'error');
        return;
    }

    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailPattern.test(el.email.value.trim())) {
        showMessage('Invalid email address.', 'error');
        return;
    }

    const payload = {
        name: el.name.value.trim(),
        rollNo: el.rollNo.value.trim(),
        department: el.department.value.trim(),
        email: el.email.value.trim(),
        year: parseInt(el.year.value, 10),
    };

    const id = el.studentId.value;
    const isEdit = !!id;

    try {
        const response = await fetch(`${API_BASE}/students${isEdit ? '/' + id : ''}`, {
            method: isEdit ? 'PUT' : 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload),
        });

        if (!response.ok) {
            const error = await response.json().catch(() => ({}));
            showMessage(error.message || 'Something went wrong.', 'error');
            return;
        }

        showMessage(isEdit ? 'Student updated successfully.' : 'Student added successfully.', 'success');
        resetForm();
        loadStudents();
    } catch (err) {
        showMessage('Unable to connect to server.', 'error');
    }
}

function startEdit(student) {
    el.studentId.value = student.id;
    el.name.value = student.name;
    el.rollNo.value = student.rollNo;
    el.department.value = student.department;
    el.email.value = student.email;
    el.year.value = student.year;
    el.formTitle.textContent = 'Edit Student';
    el.submitBtn.textContent = 'Update Student';
    el.cancelBtn.style.display = 'inline-block';
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

async function editStudent(id) {
    try {
        const response = await fetch(`${API_BASE}/students/${id}`);
        if (!response.ok) {
            showMessage('Student not found.', 'error');
            return;
        }
        const student = await response.json();
        startEdit(student);
    } catch (err) {
        showMessage('Unable to connect to server.', 'error');
    }
}

async function deleteStudent(id) {
    if (!confirm('Are you sure you want to delete this student? This will also remove their attendance records.')) {
        return;
    }
    try {
        const response = await fetch(`${API_BASE}/students/${id}`, { method: 'DELETE' });
        if (!response.ok && response.status !== 204) {
            const error = await response.json().catch(() => ({}));
            showMessage(error.message || 'Unable to delete student.', 'error');
            return;
        }
        showMessage('Student deleted successfully.', 'success');
        loadStudents();
    } catch (err) {
        showMessage('Unable to connect to server.', 'error');
    }
}

el.form.addEventListener('submit', handleSubmit);
el.cancelBtn.addEventListener('click', resetForm);
el.applyFilterBtn.addEventListener('click', applyFilters);
el.clearFilterBtn.addEventListener('click', clearFilters);

el.tableBody.addEventListener('click', (event) => {
    const button = event.target.closest('button');
    if (!button) return;
    const id = button.getAttribute('data-id');
    const action = button.getAttribute('data-action');
    if (action === 'edit') editStudent(id);
    if (action === 'delete') deleteStudent(id);
});

document.addEventListener('DOMContentLoaded', loadStudents);
