// ==========================================================
// Attendance management page logic
// Handles Create, Read, Update, Delete, Search and Filter
// via the REST API at /api/attendance and /api/students
// ==========================================================

const API_BASE = '/api';

const el = {
    message: document.getElementById('message'),
    form: document.getElementById('attendanceForm'),
    formTitle: document.getElementById('formTitle'),
    attendanceId: document.getElementById('attendanceId'),
    studentSelect: document.getElementById('studentSelect'),
    date: document.getElementById('date'),
    status: document.getElementById('status'),
    submitBtn: document.getElementById('submitBtn'),
    cancelBtn: document.getElementById('cancelBtn'),
    tableBody: document.getElementById('attendanceTableBody'),
    emptyState: document.getElementById('emptyState'),
    dateFilter: document.getElementById('dateFilter'),
    studentFilter: document.getElementById('studentFilter'),
    statusFilter: document.getElementById('statusFilter'),
    applyFilterBtn: document.getElementById('applyFilterBtn'),
    clearFilterBtn: document.getElementById('clearFilterBtn'),
};

let studentsCache = [];

function showMessage(text, type) {
    el.message.textContent = text;
    el.message.className = 'message ' + type;
    setTimeout(() => { el.message.className = 'message'; }, 4000);
}

function escapeHtml(value) {
    const div = document.createElement('div');
    div.textContent = value ?? '';
    return div.innerHTML;
}

function resetForm() {
    el.form.reset();
    el.attendanceId.value = '';
    el.formTitle.textContent = 'Mark Attendance';
    el.submitBtn.textContent = 'Save Attendance';
    el.cancelBtn.style.display = 'none';
}

function populateStudentDropdowns(students) {
    studentsCache = students;

    el.studentSelect.innerHTML = '<option value="">Select Student</option>';
    el.studentFilter.innerHTML = '<option value="">All Students</option>';

    students.forEach((s) => {
        const label = `${s.name} (${s.rollNo})`;
        el.studentSelect.appendChild(new Option(label, s.id));
        el.studentFilter.appendChild(new Option(label, s.id));
    });
}

async function loadStudentsForDropdown() {
    try {
        const response = await fetch(`${API_BASE}/students`);
        if (!response.ok) throw new Error('Failed to load students');
        const students = await response.json();
        populateStudentDropdowns(students);
    } catch (err) {
        showMessage('Unable to connect to server.', 'error');
    }
}

function renderAttendance(records) {
    el.tableBody.innerHTML = '';
    if (!records || records.length === 0) {
        el.emptyState.style.display = 'block';
        return;
    }
    el.emptyState.style.display = 'none';

    records.forEach((r) => {
        const badgeClass = r.status === 'PRESENT' ? 'present' : 'absent';
        const row = document.createElement('tr');
        row.innerHTML = `
            <td data-label="ID">${r.id}</td>
            <td data-label="Student">${escapeHtml(r.studentName)}</td>
            <td data-label="Roll Number">${escapeHtml(r.rollNo)}</td>
            <td data-label="Date">${r.date}</td>
            <td data-label="Status"><span class="badge ${badgeClass}">${r.status}</span></td>
            <td data-label="Actions">
                <button class="btn-primary btn-small" data-action="edit" data-id="${r.id}">Edit</button>
                <button class="btn-danger btn-small" data-action="delete" data-id="${r.id}">Delete</button>
            </td>
        `;
        el.tableBody.appendChild(row);
    });
}

async function loadAttendance() {
    try {
        const response = await fetch(`${API_BASE}/attendance`);
        if (!response.ok) throw new Error('Failed to load attendance');
        const records = await response.json();
        renderAttendance(records);
    } catch (err) {
        showMessage('Unable to connect to server.', 'error');
    }
}

async function applyFilters() {
    const date = el.dateFilter.value;
    const studentId = el.studentFilter.value;
    const status = el.statusFilter.value;

    const params = new URLSearchParams();
    if (date) params.append('date', date);
    if (studentId) params.append('studentId', studentId);
    if (status) params.append('status', status);

    try {
        const response = await fetch(`${API_BASE}/attendance?${params.toString()}`);
        if (!response.ok) throw new Error('Failed to load attendance');
        const records = await response.json();
        renderAttendance(records);
    } catch (err) {
        showMessage('Unable to connect to server.', 'error');
    }
}

function clearFilters() {
    el.dateFilter.value = '';
    el.studentFilter.value = '';
    el.statusFilter.value = '';
    loadAttendance();
}

async function handleSubmit(event) {
    event.preventDefault();

    if (!el.studentSelect.value || !el.date.value || !el.status.value) {
        showMessage('Please fill all required fields.', 'error');
        return;
    }

    const payload = {
        studentId: parseInt(el.studentSelect.value, 10),
        date: el.date.value,
        status: el.status.value,
    };

    const id = el.attendanceId.value;
    const isEdit = !!id;

    try {
        const response = await fetch(`${API_BASE}/attendance${isEdit ? '/' + id : ''}`, {
            method: isEdit ? 'PUT' : 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload),
        });

        if (!response.ok) {
            const error = await response.json().catch(() => ({}));
            showMessage(error.message || 'Something went wrong.', 'error');
            return;
        }

        showMessage(isEdit ? 'Attendance updated successfully.' : 'Attendance saved successfully.', 'success');
        resetForm();
        loadAttendance();
    } catch (err) {
        showMessage('Unable to connect to server.', 'error');
    }
}

function startEdit(record) {
    el.attendanceId.value = record.id;
    el.studentSelect.value = record.studentId;
    el.date.value = record.date;
    el.status.value = record.status;
    el.formTitle.textContent = 'Edit Attendance';
    el.submitBtn.textContent = 'Update Attendance';
    el.cancelBtn.style.display = 'inline-block';
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

async function editAttendance(id) {
    try {
        const response = await fetch(`${API_BASE}/attendance/${id}`);
        if (!response.ok) {
            showMessage('Attendance record not found.', 'error');
            return;
        }
        const record = await response.json();
        startEdit(record);
    } catch (err) {
        showMessage('Unable to connect to server.', 'error');
    }
}

async function deleteAttendance(id) {
    if (!confirm('Are you sure you want to delete this attendance record?')) {
        return;
    }
    try {
        const response = await fetch(`${API_BASE}/attendance/${id}`, { method: 'DELETE' });
        if (!response.ok && response.status !== 204) {
            const error = await response.json().catch(() => ({}));
            showMessage(error.message || 'Unable to delete attendance.', 'error');
            return;
        }
        showMessage('Attendance deleted successfully.', 'success');
        loadAttendance();
    } catch (err) {
        showMessage('Unable to connect to server.', 'error');
    }
}

el.form.addEventListener('submit', handleSubmit);
el.cancelBtn.addEventListener('click', resetForm);
el.applyFilterBtn.addEventListener('click', applyFilters);
el.clearFilterBtn.addEventListener('click', clearFilters);

el.tableBody.addEventListener('click', (event) => {
    const button = event.target.closest('button');
    if (!button) return;
    const id = button.getAttribute('data-id');
    const action = button.getAttribute('data-action');
    if (action === 'edit') editAttendance(id);
    if (action === 'delete') deleteAttendance(id);
});

document.addEventListener('DOMContentLoaded', () => {
    loadStudentsForDropdown();
    loadAttendance();
});
