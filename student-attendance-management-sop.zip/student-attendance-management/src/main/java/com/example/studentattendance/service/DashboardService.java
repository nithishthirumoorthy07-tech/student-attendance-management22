package com.example.studentattendance.service;

import com.example.studentattendance.dto.DashboardStatsDTO;
import com.example.studentattendance.entity.AttendanceStatus;
import com.example.studentattendance.repository.AttendanceRepository;
import com.example.studentattendance.repository.StudentRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;

/**
 * Computes dashboard statistics directly from MySQL via the
 * repositories. Nothing here is hard-coded.
 */
@Service
public class DashboardService {

    private final StudentRepository studentRepository;
    private final AttendanceRepository attendanceRepository;

    public DashboardService(StudentRepository studentRepository, AttendanceRepository attendanceRepository) {
        this.studentRepository = studentRepository;
        this.attendanceRepository = attendanceRepository;
    }

    @Transactional(readOnly = true)
    public DashboardStatsDTO getStats() {
        long totalStudents = studentRepository.count();

        LocalDate today = LocalDate.now();
        long presentToday = attendanceRepository.countByDateAndStatus(today, AttendanceStatus.PRESENT);
        long absentToday = attendanceRepository.countByDateAndStatus(today, AttendanceStatus.ABSENT);

        long totalAttendanceRecords = attendanceRepository.count();
        long totalPresent = attendanceRepository.countByStatus(AttendanceStatus.PRESENT);

        double attendancePercentage = 0.0;
        if (totalAttendanceRecords > 0) {
            attendancePercentage = (totalPresent * 100.0) / totalAttendanceRecords;
        }

        return new DashboardStatsDTO(totalStudents, presentToday, absentToday,
                Math.round(attendancePercentage * 100.0) / 100.0);
    }
}
