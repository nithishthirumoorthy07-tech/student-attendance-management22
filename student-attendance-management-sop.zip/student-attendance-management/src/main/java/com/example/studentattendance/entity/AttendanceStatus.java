package com.example.studentattendance.entity;

/**
 * Allowed attendance status values.
 */
public enum AttendanceStatus {
    PRESENT,
    ABSENT
}
