package com.example.studentattendance.service;

import com.example.studentattendance.dto.StudentRequestDTO;
import com.example.studentattendance.dto.StudentResponseDTO;
import com.example.studentattendance.entity.Student;
import com.example.studentattendance.exception.DuplicateResourceException;
import com.example.studentattendance.exception.ResourceNotFoundException;
import com.example.studentattendance.repository.StudentRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Business logic for student CRUD, search and filtering.
 * Controllers stay thin and delegate all rules here.
 */
@Service
public class StudentService {

    private final StudentRepository studentRepository;

    public StudentService(StudentRepository studentRepository) {
        this.studentRepository = studentRepository;
    }

    @Transactional
    public StudentResponseDTO createStudent(StudentRequestDTO dto) {
        if (studentRepository.existsByRollNo(dto.getRollNo())) {
            throw new DuplicateResourceException("Roll number already exists");
        }
        Student student = new Student(dto.getName(), dto.getRollNo(), dto.getDepartment(),
                dto.getEmail(), dto.getYear());
        Student saved = studentRepository.save(student);
        return toResponseDTO(saved);
    }

    @Transactional(readOnly = true)
    public List<StudentResponseDTO> getAllStudents() {
        return studentRepository.findAll().stream()
                .map(this::toResponseDTO)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public StudentResponseDTO getStudentById(Long id) {
        Student student = findStudentOrThrow(id);
        return toResponseDTO(student);
    }

    @Transactional
    public StudentResponseDTO updateStudent(Long id, StudentRequestDTO dto) {
        Student student = findStudentOrThrow(id);

        if (studentRepository.existsByRollNoAndIdNot(dto.getRollNo(), id)) {
            throw new DuplicateResourceException("Roll number already exists");
        }

        student.setName(dto.getName());
        student.setRollNo(dto.getRollNo());
        student.setDepartment(dto.getDepartment());
        student.setEmail(dto.getEmail());
        student.setYear(dto.getYear());

        Student updated = studentRepository.save(student);
        return toResponseDTO(updated);
    }

    @Transactional
    public void deleteStudent(Long id) {
        Student student = findStudentOrThrow(id);
        studentRepository.delete(student);
    }

    @Transactional(readOnly = true)
    public List<StudentResponseDTO> searchStudents(String keyword) {
        return studentRepository.searchByNameOrRollNo(keyword).stream()
                .map(this::toResponseDTO)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<StudentResponseDTO> filterStudents(String department, Integer year) {
        List<Student> results;
        if (department != null && !department.isBlank() && year != null) {
            results = studentRepository.findByDepartmentIgnoreCaseAndYear(department, year);
        } else if (department != null && !department.isBlank()) {
            results = studentRepository.findByDepartmentIgnoreCase(department);
        } else if (year != null) {
            results = studentRepository.findByYear(year);
        } else {
            results = studentRepository.findAll();
        }
        return results.stream().map(this::toResponseDTO).collect(Collectors.toList());
    }

    private Student findStudentOrThrow(Long id) {
        return studentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Student not found"));
    }

    private StudentResponseDTO toResponseDTO(Student student) {
        return new StudentResponseDTO(
                student.getId(),
                student.getName(),
                student.getRollNo(),
                student.getDepartment(),
                student.getEmail(),
                student.getYear(),
                student.getCreatedAt()
        );
    }
}
