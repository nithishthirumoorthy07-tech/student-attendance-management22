package com.example.studentattendance.dto;

/**
 * Aggregated statistics shown on the dashboard.
 * All values are computed from the database — nothing here is hard-coded.
 */
public class DashboardStatsDTO {

    private long totalStudents;
    private long presentToday;
    private long absentToday;
    private double attendancePercentage;

    public DashboardStatsDTO() {
    }

    public DashboardStatsDTO(long totalStudents, long presentToday, long absentToday, double attendancePercentage) {
        this.totalStudents = totalStudents;
        this.presentToday = presentToday;
        this.absentToday = absentToday;
        this.attendancePercentage = attendancePercentage;
    }

    public long getTotalStudents() {
        return totalStudents;
    }

    public void setTotalStudents(long totalStudents) {
        this.totalStudents = totalStudents;
    }

    public long getPresentToday() {
        return presentToday;
    }

    public void setPresentToday(long presentToday) {
        this.presentToday = presentToday;
    }

    public long getAbsentToday() {
        return absentToday;
    }

    public void setAbsentToday(long absentToday) {
        this.absentToday = absentToday;
    }

    public double getAttendancePercentage() {
        return attendancePercentage;
    }

    public void setAttendancePercentage(double attendancePercentage) {
        this.attendancePercentage = attendancePercentage;
    }
}
