package com.example.studentattendance.dto;

import java.time.LocalDateTime;

/**
 * Outgoing representation of a student, used for API responses.
 */
public class StudentResponseDTO {

    private Long id;
    private String name;
    private String rollNo;
    private String department;
    private String email;
    private Integer year;
    private LocalDateTime createdAt;

    public StudentResponseDTO() {
    }

    public StudentResponseDTO(Long id, String name, String rollNo, String department,
                               String email, Integer year, LocalDateTime createdAt) {
        this.id = id;
        this.name = name;
        this.rollNo = rollNo;
        this.department = department;
        this.email = email;
        this.year = year;
        this.createdAt = createdAt;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRollNo() {
        return rollNo;
    }

    public void setRollNo(String rollNo) {
        this.rollNo = rollNo;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Integer getYear() {
        return year;
    }

    public void setYear(Integer year) {
        this.year = year;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }
}
