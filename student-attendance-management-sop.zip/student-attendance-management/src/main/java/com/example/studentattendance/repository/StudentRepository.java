package com.example.studentattendance.repository;

import com.example.studentattendance.entity.Student;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface StudentRepository extends JpaRepository<Student, Long> {

    Optional<Student> findByRollNo(String rollNo);

    boolean existsByRollNo(String rollNo);

    boolean existsByRollNoAndIdNot(String rollNo, Long id);

    List<Student> findByDepartmentIgnoreCase(String department);

    List<Student> findByYear(Integer year);

    List<Student> findByDepartmentIgnoreCaseAndYear(String department, Integer year);

    @Query("SELECT s FROM Student s WHERE " +
            "LOWER(s.name) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "LOWER(s.rollNo) LIKE LOWER(CONCAT('%', :keyword, '%'))")
    List<Student> searchByNameOrRollNo(@Param("keyword") String keyword);
}
