package com.example.studentattendance.exception;

/**
 * Thrown for a duplicate roll number or a duplicate
 * (student_id, date) attendance combination.
 * Mapped to HTTP 409 by GlobalExceptionHandler.
 */
public class DuplicateResourceException extends RuntimeException {

    public DuplicateResourceException(String message) {
        super(message);
    }
}
