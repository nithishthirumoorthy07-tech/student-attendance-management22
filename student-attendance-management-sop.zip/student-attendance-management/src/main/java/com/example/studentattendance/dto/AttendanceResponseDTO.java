package com.example.studentattendance.dto;

import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * Outgoing representation of an attendance record, including a
 * flattened student name/roll number so the frontend doesn't need
 * a second request to display a readable table row.
 */
public class AttendanceResponseDTO {

    private Long id;
    private Long studentId;
    private String studentName;
    private String rollNo;
    private LocalDate date;
    private String status;
    private LocalDateTime createdAt;

    public AttendanceResponseDTO() {
    }

    public AttendanceResponseDTO(Long id, Long studentId, String studentName, String rollNo,
                                  LocalDate date, String status, LocalDateTime createdAt) {
        this.id = id;
        this.studentId = studentId;
        this.studentName = studentName;
        this.rollNo = rollNo;
        this.date = date;
        this.status = status;
        this.createdAt = createdAt;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getStudentId() {
        return studentId;
    }

    public void setStudentId(Long studentId) {
        this.studentId = studentId;
    }

    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public String getRollNo() {
        return rollNo;
    }

    public void setRollNo(String rollNo) {
        this.rollNo = rollNo;
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }
}
