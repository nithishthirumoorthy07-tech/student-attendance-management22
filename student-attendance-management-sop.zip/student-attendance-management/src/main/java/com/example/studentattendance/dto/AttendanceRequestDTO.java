package com.example.studentattendance.dto;

import jakarta.validation.constraints.NotNull;
import java.time.LocalDate;

/**
 * Incoming payload for creating/updating an attendance record.
 */
public class AttendanceRequestDTO {

    @NotNull(message = "Student is required")
    private Long studentId;

    @NotNull(message = "Date is required")
    private LocalDate date;

    @NotNull(message = "Status is required")
    private String status;

    public Long getStudentId() {
        return studentId;
    }

    public void setStudentId(Long studentId) {
        this.studentId = studentId;
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
