package com.example.studentattendance.service;

import com.example.studentattendance.dto.AttendanceRequestDTO;
import com.example.studentattendance.dto.AttendanceResponseDTO;
import com.example.studentattendance.entity.Attendance;
import com.example.studentattendance.entity.AttendanceStatus;
import com.example.studentattendance.entity.Student;
import com.example.studentattendance.exception.DuplicateResourceException;
import com.example.studentattendance.exception.ResourceNotFoundException;
import com.example.studentattendance.repository.AttendanceRepository;
import com.example.studentattendance.repository.StudentRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Business logic for attendance CRUD, search and filtering.
 * Enforces "one attendance record per student per day" at the
 * application level in addition to the DB unique constraint.
 */
@Service
public class AttendanceService {

    private final AttendanceRepository attendanceRepository;
    private final StudentRepository studentRepository;

    public AttendanceService(AttendanceRepository attendanceRepository, StudentRepository studentRepository) {
        this.attendanceRepository = attendanceRepository;
        this.studentRepository = studentRepository;
    }

    @Transactional
    public AttendanceResponseDTO createAttendance(AttendanceRequestDTO dto) {
        Student student = studentRepository.findById(dto.getStudentId())
                .orElseThrow(() -> new ResourceNotFoundException("Student not found"));

        if (attendanceRepository.existsByStudentIdAndDate(dto.getStudentId(), dto.getDate())) {
            throw new DuplicateResourceException("Attendance already exists for this student on this date");
        }

        AttendanceStatus status = parseStatus(dto.getStatus());
        Attendance attendance = new Attendance(student, dto.getDate(), status);
        Attendance saved = attendanceRepository.save(attendance);
        return toResponseDTO(saved);
    }

    @Transactional(readOnly = true)
    public List<AttendanceResponseDTO> getAllAttendance() {
        return attendanceRepository.findAll().stream()
                .map(this::toResponseDTO)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public AttendanceResponseDTO getAttendanceById(Long id) {
        Attendance attendance = findAttendanceOrThrow(id);
        return toResponseDTO(attendance);
    }

    @Transactional
    public AttendanceResponseDTO updateAttendance(Long id, AttendanceRequestDTO dto) {
        Attendance attendance = findAttendanceOrThrow(id);

        Student student = studentRepository.findById(dto.getStudentId())
                .orElseThrow(() -> new ResourceNotFoundException("Student not found"));

        if (attendanceRepository.existsByStudentIdAndDateAndIdNot(dto.getStudentId(), dto.getDate(), id)) {
            throw new DuplicateResourceException("Attendance already exists for this student on this date");
        }

        attendance.setStudent(student);
        attendance.setDate(dto.getDate());
        attendance.setStatus(parseStatus(dto.getStatus()));

        Attendance updated = attendanceRepository.save(attendance);
        return toResponseDTO(updated);
    }

    @Transactional
    public void deleteAttendance(Long id) {
        Attendance attendance = findAttendanceOrThrow(id);
        attendanceRepository.delete(attendance);
    }

    @Transactional(readOnly = true)
    public List<AttendanceResponseDTO> getByDate(LocalDate date) {
        return attendanceRepository.findByDate(date).stream()
                .map(this::toResponseDTO)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<AttendanceResponseDTO> getByStudent(Long studentId) {
        return attendanceRepository.findByStudentId(studentId).stream()
                .map(this::toResponseDTO)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<AttendanceResponseDTO> getByStatus(String status) {
        AttendanceStatus attendanceStatus = parseStatus(status);
        return attendanceRepository.findByStatus(attendanceStatus).stream()
                .map(this::toResponseDTO)
                .collect(Collectors.toList());
    }

    private Attendance findAttendanceOrThrow(Long id) {
        return attendanceRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Attendance not found"));
    }

    private AttendanceStatus parseStatus(String status) {
        try {
            return AttendanceStatus.valueOf(status.trim().toUpperCase());
        } catch (Exception e) {
            throw new IllegalArgumentException("Status must be PRESENT or ABSENT");
        }
    }

    private AttendanceResponseDTO toResponseDTO(Attendance attendance) {
        return new AttendanceResponseDTO(
                attendance.getId(),
                attendance.getStudent().getId(),
                attendance.getStudent().getName(),
                attendance.getStudent().getRollNo(),
                attendance.getDate(),
                attendance.getStatus().name(),
                attendance.getCreatedAt()
        );
    }
}
