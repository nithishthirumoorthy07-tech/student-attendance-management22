package com.example.studentattendance.repository;

import com.example.studentattendance.entity.Attendance;
import com.example.studentattendance.entity.AttendanceStatus;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public interface AttendanceRepository extends JpaRepository<Attendance, Long> {

    Optional<Attendance> findByStudentIdAndDate(Long studentId, LocalDate date);

    boolean existsByStudentIdAndDate(Long studentId, LocalDate date);

    boolean existsByStudentIdAndDateAndIdNot(Long studentId, LocalDate date, Long id);

    List<Attendance> findByDate(LocalDate date);

    List<Attendance> findByStudentId(Long studentId);

    List<Attendance> findByStatus(AttendanceStatus status);

    long countByDate(LocalDate date);

    long countByDateAndStatus(LocalDate date, AttendanceStatus status);

    long countByStatus(AttendanceStatus status);
}
