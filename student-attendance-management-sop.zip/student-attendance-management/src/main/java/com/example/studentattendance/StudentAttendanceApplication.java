package com.example.studentattendance;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Entry point for the Student Attendance Management and Analytics System.
 * Boots the embedded server and serves both the REST API and the
 * static frontend (HTML/CSS/JS) from src/main/resources/static.
 */
@SpringBootApplication
public class StudentAttendanceApplication {

    public static void main(String[] args) {
        SpringApplication.run(StudentAttendanceApplication.class, args);
    }
}
