package com.example.studentattendance;

import com.example.studentattendance.dto.StudentRequestDTO;
import com.example.studentattendance.dto.StudentResponseDTO;
import com.example.studentattendance.entity.Student;
import com.example.studentattendance.exception.DuplicateResourceException;
import com.example.studentattendance.exception.ResourceNotFoundException;
import com.example.studentattendance.repository.StudentRepository;
import com.example.studentattendance.service.StudentService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.*;

/**
 * Unit tests for StudentService covering creation, retrieval,
 * update, deletion and validation-driven failures.
 * Repository is mocked so no real database is required to run these.
 */
@ExtendWith(MockitoExtension.class)
class StudentServiceTest {

    @Mock
    private StudentRepository studentRepository;

    @InjectMocks
    private StudentService studentService;

    private StudentRequestDTO requestDTO;
    private Student student;

    @BeforeEach
    void setUp() {
        requestDTO = new StudentRequestDTO();
        requestDTO.setName("Test Student");
        requestDTO.setRollNo("ECE100");
        requestDTO.setDepartment("ECE");
        requestDTO.setEmail("test.student@example.edu");
        requestDTO.setYear(2);

        student = new Student("Test Student", "ECE100", "ECE", "test.student@example.edu", 2);
        student.setId(1L);
    }

    @Test
    void createStudent_savesAndReturnsStudent_whenRollNoIsUnique() {
        when(studentRepository.existsByRollNo("ECE100")).thenReturn(false);
        when(studentRepository.save(any(Student.class))).thenReturn(student);

        StudentResponseDTO result = studentService.createStudent(requestDTO);

        assertNotNull(result);
        assertEquals("Test Student", result.getName());
        assertEquals("ECE100", result.getRollNo());
        verify(studentRepository, times(1)).save(any(Student.class));
    }

    @Test
    void createStudent_throwsDuplicateException_whenRollNoAlreadyExists() {
        when(studentRepository.existsByRollNo("ECE100")).thenReturn(true);

        assertThrows(DuplicateResourceException.class, () -> studentService.createStudent(requestDTO));
        verify(studentRepository, never()).save(any(Student.class));
    }

    @Test
    void getStudentById_returnsStudent_whenFound() {
        when(studentRepository.findById(1L)).thenReturn(Optional.of(student));

        StudentResponseDTO result = studentService.getStudentById(1L);

        assertEquals("ECE100", result.getRollNo());
    }

    @Test
    void getStudentById_throwsNotFoundException_whenMissing() {
        when(studentRepository.findById(99L)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> studentService.getStudentById(99L));
    }

    @Test
    void updateStudent_updatesFields_whenValid() {
        when(studentRepository.findById(1L)).thenReturn(Optional.of(student));
        when(studentRepository.existsByRollNoAndIdNot("ECE101", 1L)).thenReturn(false);
        when(studentRepository.save(any(Student.class))).thenReturn(student);

        requestDTO.setRollNo("ECE101");
        StudentResponseDTO result = studentService.updateStudent(1L, requestDTO);

        assertNotNull(result);
        verify(studentRepository).save(any(Student.class));
    }

    @Test
    void deleteStudent_deletesStudent_whenFound() {
        when(studentRepository.findById(1L)).thenReturn(Optional.of(student));
        doNothing().when(studentRepository).delete(student);

        assertDoesNotThrow(() -> studentService.deleteStudent(1L));
        verify(studentRepository, times(1)).delete(student);
    }

    @Test
    void deleteStudent_throwsNotFoundException_whenMissing() {
        when(studentRepository.findById(anyLong())).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> studentService.deleteStudent(5L));
        verify(studentRepository, never()).delete(any(Student.class));
    }
}
