# Screenshots

Run the application locally, then capture and place screenshots here
before submitting or uploading to GitHub. Suggested filenames:

1. `01-dashboard.png` — Dashboard with live statistics
2. `02-add-student.png` — Add Student form filled in
3. `03-student-list.png` — Student table with multiple records
4. `04-edit-student.png` — Edit Student form pre-filled
5. `05-delete-student.png` — Delete confirmation dialog
6. `06-search-student.png` — Search results for a student
7. `07-attendance-page.png` — Attendance page overview
8. `08-present-attendance.png` — A PRESENT record saved
9. `09-absent-attendance.png` — An ABSENT record saved
10. `10-attendance-filter.png` — Filtered attendance results
11. `11-dashboard-stats.png` — Dashboard after marking attendance (numbers updated)
12. `12-postman-create.png` — Postman POST request/response
13. `13-postman-read.png` — Postman GET request/response
14. `14-postman-update.png` — Postman PUT request/response
15. `15-postman-delete.png` — Postman DELETE request/response
16. `16-mysql-tables.png` — MySQL Workbench/CLI showing `students` and `attendance` tables with data

Do not use placeholder or fabricated screenshots — capture these from your
own running instance of the application.
